package com.example.exam.Service;

import com.example.exam.Entity.Transaction;

import java.util.List;

public interface ITransactionService {
    Transaction saveTransaction(Transaction t) ;

    Transaction getTransactionById(long id);

    List<Transaction> getTransactions();

    String ajouterVirement(Transaction transaction);

     String ajouterRetrait(Transaction transaction);

    public void getAllTransactionByDate();



}
