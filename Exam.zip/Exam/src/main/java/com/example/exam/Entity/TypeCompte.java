package com.example.exam.Entity;

public enum TypeCompte {
    COURANT,
    EPARGNE
}
