package com.example.exam.Controller;


import com.example.exam.Entity.Transaction;
import com.example.exam.Service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("transaction")
public class TransactionController {

    private TransactionService service;

    @PostMapping("/saveTransaction")
    public Transaction saveTransaction(@RequestBody Transaction t){
        return service.saveTransaction(t);
    }


    @GetMapping("/Transactions")
    public List<Transaction> findAllTransactions(){
        return service.getTransactions();
    }

    @GetMapping("/Transaction/{id}")
    public Transaction findTransactionById(@PathVariable long id){
        return service.getTransactionById(id);
    }

    @PostMapping("/ajouterTransaction/")
    public Transaction ajouterVirement(@RequestBody Transaction t){
         service.ajouterVirement(t);
         return t;
    }
    @PostMapping("/ajouterRetrait/")
    public String ajouterRetrait(@RequestBody Transaction trans){
        service.ajouterRetrait(trans);
        return "";
    }


}
