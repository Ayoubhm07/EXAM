package com.example.exam.Repository;

import com.example.exam.Entity.Compte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompteRep extends JpaRepository<Compte, Long> {
}
