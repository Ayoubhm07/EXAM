package com.example.exam.Entity;

public enum TypeTransaction {
    VERSEMENT ,
    VIREMENT ,
    RETRAIT
}
