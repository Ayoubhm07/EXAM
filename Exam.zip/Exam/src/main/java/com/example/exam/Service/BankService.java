package com.example.exam.Service;


import com.example.exam.Entity.Bank;
import com.example.exam.Entity.Compte;
import com.example.exam.Repository.BankRep;
import com.example.exam.Repository.CompteRep;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
@Service
public class BankService implements  IBankService{

    private final BankRep rep;
    private final CompteRep repC;


    @Override
    public Bank saveBank(Bank b) {
        return rep.save(b);
    }

    @Override
    public Bank getBankById(long id) {
        return rep.findById(id).orElse(null);
    }

    @Override
    public List<Bank> getBanks() {
        return rep.findAll();
    }

    public Compte ajouterCompteEtAffecterAAgence(Compte compte, String agenceBank){
        Bank bank = rep.findByAgence(agenceBank);
        if (bank!= null){
            bank.setComptes((Set<Compte>) compte);
            repC.save(compte);
        }
        return compte;
    }

}
