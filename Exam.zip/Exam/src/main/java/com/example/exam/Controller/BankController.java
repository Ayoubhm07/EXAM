package com.example.exam.Controller;


import com.example.exam.Entity.Bank;
import com.example.exam.Service.BankService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("bank")

public class BankController {

    private BankService service;

    @PostMapping("/saveBank")
    public Bank saveBank(@RequestBody Bank b){
        return service.saveBank(b);
    }


    @GetMapping("/Banks")
    public List<Bank> findAllBanks(){
        return service.getBanks();
    }

    @GetMapping("/Bank/{id}")
    public Bank findBankById(@PathVariable long id){
        return service.getBankById(id);
    }
}
