package com.example.exam.Controller;


import com.example.exam.Entity.Compte;
import com.example.exam.Service.CompteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("compte")
public class CompteController {

    private CompteService service;

    @PostMapping("/saveCompte")
    public Compte saveCompte(@RequestBody Compte c){
        return service.saveCompte(c);
    }


    @GetMapping("/Comptes")
    public List<Compte> findAllComptes(){
        return service.getComptes();
    }

    @GetMapping("/Compte/{id}")
    public Compte findCompteById(@PathVariable long id){
        return service.getCompteById(id);
    }
}
