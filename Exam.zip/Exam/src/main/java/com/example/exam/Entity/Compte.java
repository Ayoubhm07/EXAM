package com.example.exam.Entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "compte")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder

public class Compte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idBank")
    @Setter(AccessLevel.NONE)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private long id_compte;

    @Column(name = "code")
    private long code;

    @Column(name = "solde")
    private double solde;

    @Column(name = "typec")
    @Enumerated(EnumType.STRING)
    private TypeCompte typeC;
}
