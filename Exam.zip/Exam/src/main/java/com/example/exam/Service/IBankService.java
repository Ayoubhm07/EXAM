package com.example.exam.Service;

import com.example.exam.Entity.Bank;
import com.example.exam.Entity.Compte;

import java.util.List;

public interface IBankService {
    Bank saveBank(Bank b) ;

    Bank getBankById(long id);

    List<Bank> getBanks();

    Compte ajouterCompteEtAffecterAAgence(Compte compte, String agenceBank);

}
