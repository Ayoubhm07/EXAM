package com.example.exam.Entity;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "transaction")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_t")
    @Setter(AccessLevel.NONE)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private long id_t;

    @Column(name = "lontant")
    private double montant ;

    @Column(name="date_t")
    @Temporal(TemporalType.DATE)
    private LocalDate date_t;

    @Column(name = "type_t")
    @Enumerated(EnumType.STRING)
    private TypeTransaction typeT;

    @ManyToOne(cascade = CascadeType.ALL )
    Compte compte;

}
