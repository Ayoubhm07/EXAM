package com.example.exam.Repository;

import com.example.exam.Entity.Transaction;
import com.example.exam.Entity.TypeTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface TransactionRep extends JpaRepository<Transaction , Long> {

    @Query("SELECT t FROM Transaction t WHERE t.compte.typeC = :typec AND t.typeT = :typet")
    Set<Transaction> getTransactionByTypeTAndTypeC(@Param("typec") String typec, @Param("typet") String typet);


    @Query("SELECT t FROM Transaction t WHERE t.compte.solde >t.montant+2 AND t.typeT = :typet")
    Set<Transaction> getTransactionByTypeTAndSolde( @Param("typet") String typet);

    @Query("SELECT t FROM Transaction t WHERE t.compte.solde < t.montant+3 ")
    Set<Transaction> getTransactionByCompteSolde();

    Set<Transaction> trans getAllTransactionsByDate();
}
