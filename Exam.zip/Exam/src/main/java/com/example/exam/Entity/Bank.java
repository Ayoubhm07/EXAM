package com.example.exam.Entity;


import jakarta.persistence.*;
import lombok.*;

import java.util.Set;

@Entity
@Table(name = "bank")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class Bank {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idBank")
    @Setter(AccessLevel.NONE)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private long id_bank;

    @Column(name = "nom")
    private String nom;
    @Column(name = "agence")

    private String agence;
    @Column(name = "adresse")

    private String adresse;

    @OneToMany(cascade = CascadeType.ALL , mappedBy = "bank")
    Set <Compte> comptes;

}
