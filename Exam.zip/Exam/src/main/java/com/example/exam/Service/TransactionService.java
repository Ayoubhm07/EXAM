package com.example.exam.Service;


import com.example.exam.Entity.Transaction;
import com.example.exam.Entity.TypeTransaction;
import com.example.exam.Repository.TransactionRep;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.weaver.ast.And;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
@Service
@Slf4j

public class TransactionService implements ITransactionService {

    private final TransactionRep rep;

    @Override
    public Transaction saveTransaction(Transaction t) {
        return rep.save(t);
    }

    @Override
    public Transaction getTransactionById(long id) {
        return rep.findById(id).orElse(null);
    }

    @Override
    public List<Transaction> getTransactions() {
        return rep.findAll();
    }

    @Override
    public String ajouterVirement(Transaction transaction) {
        Set<Transaction> transE = rep.getTransactionByTypeTAndTypeC("EPARGNE", "VIREMENT");
        Set<Transaction> transC = rep.getTransactionByTypeTAndTypeC("COURANT", "VIREMENT");
        Set<Transaction> trannIns = rep.getTransactionByCompteSolde();
        if (transaction == transE) {
            log.warn("On ne peut pas faire un virement à partir \n" +
                    "d’un compte épargne!");
        } else if (transaction == transC && transaction == trannIns) {
             log.warn("On ne peut pas faire un virement : Solde \n" +
                    "insuffisant");
        } else {
            rep.save(transaction);
            return " VIREMENT de 10.000 DT de compte 3 vers le compte 2 approuvé avec \n" +
                    "succès !";
        }

        return "Finish !";

    }

    @Override
    public String ajouterRetrait(Transaction transaction){
        Set<Transaction> transactionsok = rep.getTransactionByTypeTAndSolde("RETRAIT");
        if(transaction == transactionsok){
            rep.save(transaction);
            log.warn(" RETRAIT de 4.000 DT de compte 1 approuvé avec succès. »");
        }
        else {
            log.warn(" « On ne peut pas faire un \n" +
                    "retrait : Solde insuffisant»");
        }


        return "Finished!";

    }


    @Override
    public void getAllTransactionByDate(){
        Set<Transaction> transactions = getAllTransactionsByDate();
        return transactions();
    }







}
