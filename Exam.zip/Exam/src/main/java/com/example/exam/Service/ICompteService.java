package com.example.exam.Service;

import com.example.exam.Entity.Compte;

import java.util.List;

public interface ICompteService {

    Compte saveCompte(Compte b) ;

    Compte getCompteById(long id);

    List<Compte> getComptes();




}
