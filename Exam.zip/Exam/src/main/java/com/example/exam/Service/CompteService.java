package com.example.exam.Service;


import com.example.exam.Entity.Bank;
import com.example.exam.Entity.Compte;
import com.example.exam.Repository.BankRep;
import com.example.exam.Repository.CompteRep;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CompteService implements ICompteService{
@Autowired
    private final CompteRep rep;

    private final BankRep repB;

    @Override
    public Compte saveCompte(Compte c) {
        return rep.save(c);
    }

    @Override
    public Compte getCompteById(long id) {
        return rep.findById(id).orElse(null);
    }

    @Override
    public List<Compte> getComptes() {
        return rep.findAll();
    }



}
